import { createSignal, createEffect, For, Show, mergeProps } from "solid-js";
import * as Plot from "@observablehq/plot";
import { timeFormat, isoParse } from "d3-time-format";
import { createGraphQLClient, gql, request } from "@solid-primitives/graphql";
import YAML from 'yaml';
import Jsonata from "jsonata";


let jdata = {
  example: [
    {value: 4},
    {value: 7},
    {value: 13}
  ]
};

let expression = Jsonata("(Disease.newCases)[[0..20]]");
//let reslt = expression.evaluate(jdata);

//console.log(reslt);

const format = timeFormat("%y-%m-%d");
const formatDate = (date) => format(isoParse(date));
const query = createGraphQLClient("http://localhost:8080/v1/graphql");
const [sortDirection, setSortDirection] = createSignal();
const [action, setAction] = createSignal();
const [option, setOption] = createSignal();
const [fillcolor, setFillcolor] = createSignal("steelblue");

const Plotbar = (props) => {
  const newProps = mergeProps(props);
  //const [fillcolor, setFillcolor] = createSignal("steelblue");

  setAction(newProps.action);
  setSortDirection(newProps.setSortDirection);

  const [gdata] = query(
    gql`
      query ($sortDirection: [Disease_order_by!], $action: Disease_bool_exp) {
        Disease(order_by: $sortDirection, where: $action) {
          date
          newCases
        }
      }
    `,
    () => ({ sortDirection: sortDirection(), action: action() })
  );

  let myDiv = <div id="svd"></div>;
  document.body.appendChild(myDiv);

 

createEffect(() => {
  
myDiv.append(Plot.plot(option()));
});

let qt;

const fn = (event) => {
  event.preventDefault();
  setAction(YAML.parse(qy.value));
  
}

let fc;

const fcf = (e) => {
  e.preventDefault();
  setFillcolor(nf.value);
}


const ofn = (e) => {
  e.preventDefault();
  setOption({
    marginLeft: 120,
    y: {
      grid: true,
    },
    marks: [
      Plot.line(gdata()["Disease"], {
        x: (d) => formatDate(d.date),
        y: "newCases",
        stroke: fillcolor()
      }),
    ],
  });
};


//console.log(YAML.parse("{ newCases: { _gte: 0 } }"))

  return (
    <div>
      <form onSubmit={fn}>
        <textarea rows="5" cols="50" id="qy" ref={qt} />

        <button>query</button>
      </form>
      <form onSubmit={fcf}>
        <input id="nf" ref={fc} />

        <button>new color</button>
      </form>
      <button
        onClick={ ofn }
      >
        Show Line Chart
      </button>
      <Show when={gdata()} fallback={<div>Loading...</div>}>
        { console.log(expression.evaluate(gdata()))}
        <div>
          {Plot.plot({
            marginLeft: 120,
            marks: [
              Plot.ruleY([0]),
              Plot.barY(gdata()["Disease"], {
                x: (d) => formatDate(d.date),
                y: "newCases",
                fill: fillcolor(),
              }),
            ],
          })}
        </div>
      </Show>
    </div>
  );
};

function App() {
//let pDiv;

  return (
    <Plotbar
      //ref={pDiv}
      action={{ newCases: { _gte: 300000 } }}
      sortDirection={{ date: "asc" }}
      
    />
  );
}

export default App;
