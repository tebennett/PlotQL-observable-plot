import { createSignal, createEffect, For, Show, mergeProps } from "solid-js";
import * as Plot from "@observablehq/plot";
import { timeFormat, isoParse } from "d3-time-format";
import { createGraphQLClient, gql, request } from "@solid-primitives/graphql";
import { Card, Form, Button, Container, Row, Col } from "solid-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import YAML from "yaml";
import Jsonata from "jsonata";

let jdata = {
  example: [{ value: 4 }, { value: 7 }, { value: 13 }],
};

let expression = Jsonata("(Disease.newCases)[[0..20]]");
//let reslt = expression.evaluate(jdata);

//console.log(reslt);

const format = timeFormat("%y-%m-%d");
const formatDate = (date) => format(isoParse(date));

const PlotLine = (props) => {
  const lprops = mergeProps(props);

  return (
    <div>
      {Plot.plot({
        marginLeft: 120,
        y: {
          grid: true,
        },
        marks: [
          Plot.line(lprops.info, {
            x: (d) => formatDate(d.date),
            y: "newCases",
            stroke: lprops.color,
          }),
        ],
      })}
    </div>
  );
};

const PlotBar = (props) => {
  const bprops = mergeProps(props);

  return (
    <div>
      {Plot.plot({
        marginLeft: 120,
        marks: [
          Plot.ruleY([0]),
          Plot.barY(bprops.info, {
            x: (d) => formatDate(d.date),
            y: "newCases",
            fill: bprops.color,
          }),
        ],
      })}
    </div>
  );
};

const items = {
  bar: PlotBar,
  line: PlotLine,
};

const PlotController = (props) => {
  const client = createGraphQLClient("http://localhost:8080/v1/graphql");

  const [sortDirection, setSortDirection] = createSignal();
  const [action, setAction] = createSignal();
  const [selected, setSelected] = createSignal("bar");
  const [fillcolor, setFillcolor] = createSignal("steelblue");
  const newProps = mergeProps(props);
  setAction(newProps.action);
  setSortDirection(newProps.setSortDirection);

  const [gdata] = client(newProps.query, () => ({
    sortDirection: sortDirection(),
    action: action(),
  }));

  //let fc;

  const fcf = (e) => {
    e.preventDefault();
    let ftx = document.getElementById(`fc${newProps.tag}`);
    setFillcolor(ftx.value);
  };

  let qt;
  const fn = (event) => {
    event.preventDefault();
    let vtx = document.getElementById(`tx${newProps.tag}`);
    setAction(YAML.parse(vtx.value));
  };
  
//    id={`fc${newProps.tag}`}

  return (
    <Card>
      <Card.Body>
        <div>
          <Form onSubmit={fn}>
            <Form.Group class="sm-3" controlId="plotform.ControlInput1">
              <Form.Label>Enter Hasura Query</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                id={`tx${newProps.tag}`}
              ></Form.Control>

              <Button variant="secondary" type="submit">
                query
              </Button>
            </Form.Group>
          </Form>

          <Form onSubmit={fcf}>
            <Form.Group class="sm-3" controlId="PlotForm.ColorControl1">
              <br />
              <Form.Control size="sm" type="text"  id={`fc${newProps.tag}`}/>

              <Button variant="primary" type="submit">
                New Color
              </Button>
            </Form.Group>
            <br />
          </Form>

          <Show when={gdata()} fallback={<div>Loading...</div>}>
            <>
              <Form.Select
                value={selected()}
                onInput={(e) => setSelected(e.currentTarget.value)}
              >
                <For each={Object.keys(items)}>
                  {(fnc) => <option value={fnc}>{fnc}</option>}
                </For>
              </Form.Select>
              <Dynamic
                component={items[selected()]}
                info={gdata()["Disease"]}
                tag={newProps.tag}
                color={fillcolor()}
              />
            </>
          </Show>
        </div>
      </Card.Body>
    </Card>
  );

  //<div id={newProps.tag}></div>
};

function App() {
  //let pDiv;

  return (
    <Container>
      <Row>
        <Col>
          <PlotController
            tag={"vis"}
            action={{ newCases: { _gte: 300000 } }}
            sortDirection={{ date: "asc" }}
            query={gql`
              query (
                $sortDirection: [Disease_order_by!]
                $action: Disease_bool_exp
              ) {
                Disease(order_by: $sortDirection, where: $action) {
                  date
                  newCases
                }
              }
            `}
          />
        </Col>
        <Col>
          <PlotController
            tag={"ivs"}
            action={{ newCases: { _gte: 0 } }}
            sortDirection={{ date: "asc" }}
            query={gql`
              query (
                $sortDirection: [Disease_order_by!]
                $action: Disease_bool_exp
              ) {
                Disease(order_by: $sortDirection, where: $action) {
                  date
                  newCases
                }
              }
            `}
          />
        </Col>
      </Row>
    </Container>
  );
}

export default App;
